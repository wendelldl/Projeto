import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ConfigService } from './services/configservice';
import { ClienteService } from './services/cliente.service';
import { VendedorService } from './services/vendedor.service';
import { CadastroClienteComponent } from './cadastro-cliente/cadastro-cliente.component';
import { CadastroVendedorComponent } from './cadastro-vendedor/cadastro-vendedor.component';
import { RelatorioClientesComponent } from './relatorio-clientes/relatorio-clientes.component';
import { RelatorioVendedoresComponent } from './relatorio-vendedores/relatorio-vendedores.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { DistribuicaoClientesComponent } from './distribuicao-clientes/distribuicao-clientes.component';

@NgModule({
  declarations: [
    AppComponent,
    CadastroClienteComponent,
    CadastroVendedorComponent,
    RelatorioClientesComponent,
    RelatorioVendedoresComponent,
    HomeComponent,
    MenuComponent,
    DistribuicaoClientesComponent
  ],
  imports: [
    BrowserModule,
    BrowserModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    AppRoutingModule,
    HttpModule
  ],
  providers: [ConfigService, ClienteService, VendedorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
