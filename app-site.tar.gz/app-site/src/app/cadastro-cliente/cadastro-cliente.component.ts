import { ResponseCliente } from './../services/reponsecliente';
import { ClienteService } from './../services/cliente.service';
import { Component, OnInit } from '@angular/core';

import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { Cliente } from '../services/cliente';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';
 

@Component({
  selector: 'app-cadastro-cliente',
  templateUrl: './cadastro-cliente.component.html',
  styleUrls: ['./cadastro-cliente.component.css']
})
export class CadastroClienteComponent implements OnInit {

  private titulo:string;
  private cliente:Cliente = new Cliente();

  constructor(private clienteService: ClienteService,
    private router: Router,
    private activatedRoute: ActivatedRoute){}

  /*CARREGADO NA INICIALIZAÇÃO DO COMPONENTE */  
  ngOnInit() {

    this.activatedRoute.params.subscribe(parametro=>{

      if(parametro["codigo_cliente"] == undefined){

        this.titulo = "Cadastro de Cliente";
      }
      else{
        this.titulo = "Alterar Cadastro de Cliente";
          this.clienteService.getCliente(Number(parametro["codigo_cliente"])).subscribe(res => this.cliente = res);
      }
    });
  }

   /*FUNÇÃO PARA SALVAR UM NOVO REGISTRO OU ALTERAÇÃO EM UM REGISTRO EXISTENTE */
   salvar():void {
 
    /*SE NÃO TIVER CÓDIGO VAMOS INSERIR UM NOVO REGISTRO */
    if(this.cliente.codigo_cliente == undefined){

      /*CHAMA O SERVIÇO PARA ADICIONAR UM NOVO CLIENTE */
      this.clienteService.addCliente(this.cliente).subscribe(response => {

         //PEGA O RESPONSE DO RETORNO DO SERVIÇO
         let res:ResponseCliente = <ResponseCliente>response;

         /*SE RETORNOU 1 DEVEMOS MOSTRAR A MENSAGEM DE SUCESSO
         E LIMPAR O FORMULÁRIO PARA INSERIR UM NOVO REGISTRO*/
         if(res.codigo_cliente == 1){
          alert(res.mensagem);
          this.cliente = new Cliente();
         }
         else{
           /*
           ESSA MENSAGEM VAI SER MOSTRADA CASO OCORRA ALGUMA EXCEPTION
           NO SERVIDOR (CODIGO = 0)*/
           alert(res.mensagem);
         }
       },
       (erro) => {   
         /**AQUI VAMOS MOSTRAR OS ERROS NÃO TRATADOS
           EXEMPLO: SE APLICAÇÃO NÃO CONSEGUIR FAZER UMA REQUEST NA API*/                 
          alert(erro);
       });

    }
    else{

      /*AQUI VAMOS ALTERAR AS INFORMAÇÕES DE UM REGISTRO EXISTENTE */
      this.clienteService.alterarCliente(this.cliente).subscribe(response => {

      //PEGA O RESPONSE DO RETORNO DO SERVIÇO
      let res:ResponseCliente = <ResponseCliente>response;

       /*SE RETORNOU 1 DEVEMOS MOSTRAR A MENSAGEM DE SUCESSO
         E REDIRECIONAR O USUÁRIO PARA A PÁGINA DE CONSULTA*/
      if(res.codigo_cliente == 1){
        alert(res.mensagem);
        this.router.navigate(['/relatorio-clientes']);
      }
       else{
        /*ESSA MENSAGEM VAI SER MOSTRADA CASO OCORRA ALGUMA EXCEPTION
        NO SERVIDOR (CODIGO = 0)*/
         alert(res.mensagem);
       }
     },
     (erro) => {                    
       /**AQUI VAMOS MOSTRAR OS ERROS NÃO TRATADOS
        EXEMPLO: SE APLICAÇÃO NÃO CONSEGUIR FAZER UMA REQUEST NA API*/                 
        alert(erro);
     });
    }

  }
}
