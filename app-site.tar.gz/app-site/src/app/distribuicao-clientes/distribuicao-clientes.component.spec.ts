import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DistribuicaoClientesComponent } from './distribuicao-clientes.component';

describe('DistribuicaoClientesComponent', () => {
  let component: DistribuicaoClientesComponent;
  let fixture: ComponentFixture<DistribuicaoClientesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DistribuicaoClientesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DistribuicaoClientesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
