import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distribuicao-clientes',
  templateUrl: './distribuicao-clientes.component.html',
  styleUrls: ['./distribuicao-clientes.component.css']
})
export class DistribuicaoClientesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
