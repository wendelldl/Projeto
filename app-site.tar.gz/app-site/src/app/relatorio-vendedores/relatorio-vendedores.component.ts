import { ResponseVendedor } from './../services/responsevendedor';
import { Vendedor } from './../services/vendedor';
import { Component, OnInit } from '@angular/core';
import { VendedorService } from '../services/vendedor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-relatorio-vendedores',
  templateUrl: './relatorio-vendedores.component.html',
  styleUrls: ['./relatorio-vendedores.component.css']
})
export class RelatorioVendedoresComponent implements OnInit {

  private vendedores: Vendedor[] = new Array();
  private titulo:string;

  constructor(private vendedorService: VendedorService,
              private router: Router){}

  ngOnInit() {

    /*SETA O TÍTULO */
    this.titulo = "Vendedores Cadastrados";

    /*CHAMA O SERVIÇO E RETORNA TODOS OS CLIENTES CADASTRADOS */
    this.vendedorService.getVendedores().subscribe(res => this.vendedores = res);
  }

  /**EXCLUI UM REGISTRO QUANDO CLICAMOS NA OPÇÃO EXCLUIR DE UMA 
   * LINHA DA TABELA*/
  excluir(codigo_vendedor:number, index:number):void {

    if(confirm("Deseja realmente excluir esse registro?")){

      /*CHAMA O SERVIÇO PARA REALIZAR A EXCLUSÃO */
      this.vendedorService.excluirVendedor(codigo_vendedor).subscribe(response => {

            /**PEGA O RESPONSE DO SERVIÇO */
            let res:ResponseVendedor = <ResponseVendedor>response;

            /*1 = SUCESSO
            * MOSTRAMOS A MENSAGEM RETORNADA PELO SERVIÇO E DEPOIS REMOVEMOS
            O REGISTRO DA TABELA HTML*/
            if(res.codigo_vendedor == 1){
              alert(res.mensagem);
              this.vendedores.splice(index,1);
            }
            else{
              /*0 = EXCEPTION GERADA NO SERVIÇO JAVA */
              alert(res.mensagem);
            }
        },
        (erro) => {                    
             /*MOSTRA ERROS NÃO TRATADOS */
             alert(erro);
        });        
    }

  }

  Alterar(codigo_vendedor:number):void{

    this.router.navigate(['/relatorio-vendedores',codigo_vendedor]);

  }

}