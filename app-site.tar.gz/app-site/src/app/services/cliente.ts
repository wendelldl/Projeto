export class Cliente{
 
    codigo_cliente:number;
    cnpj:string;				
    razaosocial:string;
    latitude:string;
    longitude:string;
}