export class ResponseCliente{
 
    codigo_cliente:number;
    mensagem:string;
}