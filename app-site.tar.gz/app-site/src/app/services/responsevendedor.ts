export class ResponseVendedor{
 
    codigo_vendedor:number;
    mensagem:string;
}