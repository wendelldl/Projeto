import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Headers} from '@angular/http';
import { RequestOptions } from '@angular/http';
 
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/Rx';
 
import {Vendedor} from '../services/vendedor';
import {ConfigService} from '../services/configservice'; 
 
@Injectable()
export class VendedorService {
 
    private baseUrlService:string = '';
    private headers:Headers;
    private options:RequestOptions;
 
    constructor(private http: Http,
                private configService: ConfigService) { 
 
        /**SETANDO A URL DO SERVIÇO REST QUE VAI SER ACESSADO */
        this.baseUrlService = configService.getUrlService() + '/vendedor/';
 
        /*ADICIONANDO O JSON NO HEADER */
        this.headers = new Headers({ 'Content-Type': 'application/json;charset=UTF-8' });                
        this.options = new RequestOptions({ headers: this.headers });
    }
 
    /**CONSULTA TODOS OS VENDEDORES CADASTRADOS */
    getVendedores(){        
        return this.http.get(this.baseUrlService).map(res => res.json());
    }
 
    /**ADICIONA UM NOVO VENDEDOR */
    addVendedor(vendedor: Vendedor){
 
        return this.http.post(this.baseUrlService, JSON.stringify(vendedor),this.options)
        .map(res => res.json());
    }
    /**EXCLUI UM VENDEDOR */
    excluirVendedor(codigo_vendedor:number){
 
        return this.http.delete(this.baseUrlService + codigo_vendedor).map(res => res.json());
    }
 
    /**CONSULTA UM VENDEDOR PELO CÓDIGO */
    getVendedor(codigo_vendedor:number){
 
        return this.http.get(this.baseUrlService + codigo_vendedor).map(res => res.json());
    }
 
    /**ALTERA INFORMAÇÕES DO VENDEDOR */
    alterarVendedor(vendedor:Vendedor){
 
        return this.http.put(this.baseUrlService, JSON.stringify(vendedor),this.options)
        .map(res => res.json());
    }
 
}