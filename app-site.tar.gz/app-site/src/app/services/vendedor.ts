export class Vendedor{
 
    codigo_vendedor:number;
    cpf:string;				
    nomevendedor:string;
    latitude:string;
    longitude:string;
}